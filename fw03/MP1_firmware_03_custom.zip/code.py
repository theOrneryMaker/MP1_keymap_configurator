# code.py – MP1 macropad: hardware setup, then hand off to the main loop.
# Behavior lives in lib/macropad/app.py; keys in keymap.json; device settings in settings.json;
# pins in wiring.json (see lib/macropad/pins.py).

import gc
import time
import board
import busio
import digitalio
import displayio
import keypad
import rotaryio
import usb_hid

RESERVE_BYTES = 10240     # see "Room kept for later" below

# The keymap first, while memory is still in one piece: each layer's text is read in one block
# (a few KB for a big macro layer), and later, with everything else loaded, the free memory is
# split into smaller gaps. Its packed layers stay; the loader is let go further down.
# The files that stay loaded while running, but that the keymap loader needs too, are loaded
# first: loaded by it, they'd sit in the middle of the space it frees and break that up.
from macropad import layers
from mp1 import clock, actions, lights      # noqa: F401
from adafruit_hid.keycode import Keycode                # noqa: F401
from mp1 import keymap
km = keymap.load()                      # keymap.json checked and packed; problems in keymap.ERRORS
gc.collect()

# Room kept for later: one block set aside now, while memory is still in one piece, and given
# back as the last step of start-up. Everything loaded after this goes around it, so while running
# there's one large free area for what's loaded on demand (the TOOLS menu, modules, MP1 Link).
# Without it the free memory ends up in many small pieces, and loading those can fail even with
# plenty free.
reserve = bytearray(RESERVE_BYTES)

from macropad.app import App, NoAddon, forget_modules
gc.collect()

from i2cdisplaybus import I2CDisplayBus
from adafruit_displayio_ssd1306 import SSD1306
from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keyboard_layout_us import KeyboardLayoutUS
from adafruit_hid.mouse import Mouse
from adafruit_hid.consumer_control import ConsumerControl

from mp1 import pins
from macropad import settings
from mp1.display import Screen, show_splash
from mp1.actions import Actions
gc.collect()

cfg = settings.load()
import mp1                              # debug mode: the start-up details kept so far are printed
mp1.DEBUG = cfg["boot_debug"]
if mp1.DEBUG:
    for parts in mp1.NOTES:
        print(*parts)
mp1.NOTES = None
keymap.add_gestures(km, cfg)
wiring = pins.load()                    # wiring.json, checked; problems in wiring.errors
mp1.note("Pins from", wiring.source)
for problem in wiring.errors:
    print("WIRING:", problem)

# OLED (if the screen pins from wiring.json don't work, try the standard MP1 pins)
displayio.release_displays()
try:
    i2c = busio.I2C(wiring.I2C_SCL, wiring.I2C_SDA, frequency=wiring.I2C_FREQUENCY)
except (ValueError, RuntimeError) as e:
    if wiring.source == "the standard MP1 pins":
        raise
    problems = wiring.errors + ["Screen didn't start on the wiring.json pins ({}); using the standard MP1 pins".format(e)]
    wiring = pins.standard()
    wiring.errors = problems
    i2c = busio.I2C(wiring.I2C_SCL, wiring.I2C_SDA, frequency=wiring.I2C_FREQUENCY)
display = SSD1306(I2CDisplayBus(i2c, device_address=wiring.OLED_ADDRESS), width=128, height=64)

# Start-up screen: Boot/boot.bmp (boot.py showed Boot/startup.bmp until now), or (boot_debug on) the console text with the start-up messages
boot_started = time.monotonic()
splash = None if cfg["boot_debug"] else show_splash(display)

# Inputs / LED
led = digitalio.DigitalInOut(board.LED)
led.switch_to_output()

# Optional add-ons: if one fails to start, it's reported and the macropad carries on without it.
# One that isn't fitted (or didn't start) is replaced by a stand-in that does nothing, and its
# code (lights.py / sound.py) is let go below.
lights = NoAddon()
if cfg["led_count"] > 0:
    from mp1.lights import Lights
    lights = Lights(cfg, wiring.LED_STRIP_PIN)
    if lights.pixels is None:
        lights = NoAddon(lights.error)
    del Lights
sound = NoAddon()
if cfg["buzzer"] != "none":
    from mp1.sound import Sound
    sound = Sound(cfg, wiring.BUZZER_PIN)
    if not sound.present:
        sound = NoAddon(sound.error)
    del Sound
hardware_errors = [part.error for part in (lights, sound) if part.error]
if cfg["led_count"] > 0:                # drop-in scene files that were skipped (scenes/)
    from mp1.lights import SCENE_ERRORS
    hardware_errors += SCENE_ERRORS
    del SCENE_ERRORS

# USB HID
kbd = Keyboard(usb_hid.devices)
actions = Actions(kbd, KeyboardLayoutUS(kbd), ConsumerControl(usb_hid.devices), Mouse(usb_hid.devices))

gc.collect()
mp1.note("Free memory before the screen starts:", gc.mem_free(), "bytes")

# Keep the start-up screen up for at least boot_screen_seconds
while time.monotonic() - boot_started < cfg["boot_screen_seconds"]:
    time.sleep(0.02)
splash = None

# Keys, encoder and its button. If they can't start on these pins (wiring.json is wrong for
# this board), show why on the screen instead of stopping with an error.
try:
    keys = keypad.KeyMatrix(row_pins=wiring.ROWS, column_pins=wiring.COLS, columns_to_anodes=True)
    encoder = rotaryio.IncrementalEncoder(wiring.ENC_A, wiring.ENC_B, divisor=cfg["encoder_divisor"])
    button = digitalio.DigitalInOut(wiring.ENC_SW)
    button.switch_to_input(pull=digitalio.Pull.UP)
except (ValueError, RuntimeError, TypeError) as e:
    from mp1.display import show_text_screen
    problems = wiring.errors + ["Keys / encoder didn't start: {}".format(e)]
    for problem in problems:
        print("WIRING:", problem)
    show_text_screen(display, "WIRING PROBLEM", problems)
    while True:
        time.sleep(1)

errors = wiring.errors + keymap.ERRORS + settings.ERRORS + hardware_errors
# pins.py, the keymap and settings loaders and the file reader are only needed to start up:
# free them, and lights.py / sound.py if that add-on isn't there (the main loop prints the
# memory left after this)
del wiring, pins, keymap, settings
forget_modules("pins", "keymap", "settings", "jsfile", "profiles")
if isinstance(lights, NoAddon):
    forget_modules("lights")
if isinstance(sound, NoAddon):
    forget_modules("sound")
gc.collect()

app = App(
    keymap=km,
    cfg=cfg,
    errors=errors,
    screen=Screen(display),
    actions=actions,
    keys=keys,
    encoder=encoder,
    button=button,
    led=led,
    lights=lights,
    sound_out=sound,
)
reserve = None                          # the room kept for later: free again now
gc.collect()
app.run()
