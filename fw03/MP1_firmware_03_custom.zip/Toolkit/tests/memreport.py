# Toolkit/tests/memreport.py - where the memory goes: free memory after each part of start-up.
# From the serial console: press Ctrl+C to stop code.py, any key for the >>> prompt, then:
#
#   from Toolkit.tests import memreport
#
# It does what code.py does at start-up, one part at a time (code, libraries, keymap.json,
# settings, screen, add-ons, the main loop's object), printing the free memory after each
# and how much that part took. The main loop isn't started. Ctrl+D restarts normally.
# (This test's own code takes a little memory too, so the totals are slightly lower than
# the "Free memory while running" line at a normal start-up.)

import gc

gc.collect()
_last = [gc.mem_free()]
_lowest = [_last[0]]
print()
print("{:<36}{:>8}{:>8}".format("Part", "free", "took"))


def step(name):
    gc.collect()
    free = gc.mem_free()
    print("{:<36}{:>8}{:>8}".format(name[:35], free, _last[0] - free))
    _last[0] = free
    _lowest[0] = min(_lowest[0], free)


step("(start)")
import board
import busio
import digitalio
import displayio
import keypad
import rotaryio
import usb_hid
step("CircuitPython built-ins")

# The keymap first, as code.py does (while memory is still in one piece), after the files it
# shares with the main loop
from macropad import layers
from mp1 import clock, actions, lights      # noqa: F401
from adafruit_hid.keycode import Keycode                # noqa: F401
step("code: clock, actions, layers, lights, keycode")
from mp1 import keymap
step("code: keymap loader")
km = keymap.load()
step("keymap.json ({} layers, packed)".format(len(km.LAYER_NAMES)))
reserve = bytearray(10240)              # room kept for later, as code.py does
step("room kept for later (10 KB)")

# Libraries first, so each macropad part below counts only its own code
from i2cdisplaybus import I2CDisplayBus
from adafruit_displayio_ssd1306 import SSD1306
step("lib: OLED driver")
from adafruit_hid.keycode import Keycode
step("lib: hid keycode")
from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keyboard_layout_us import KeyboardLayoutUS
step("lib: hid keyboard + US layout")
from adafruit_hid.mouse import Mouse
from adafruit_hid.consumer_control import ConsumerControl
step("lib: hid mouse + media keys")

for _name in ("clock", "modes", "gestures", "lights", "jsfile", "settings", "timer",
              "stopwatch", "sound", "guard", "actions", "layers", "display", "controls", "commands",
              "extras", "app"):
    __import__("macropad." + _name)
    step("code: " + _name)

from mp1 import pins
wiring = pins.load()
step("code + data: pins / wiring.json")
from macropad import settings
cfg = settings.load()
keymap.add_gestures(km, cfg)
step("settings.json")

displayio.release_displays()
i2c = busio.I2C(wiring.I2C_SCL, wiring.I2C_SDA, frequency=wiring.I2C_FREQUENCY)
display = SSD1306(I2CDisplayBus(i2c, device_address=wiring.OLED_ADDRESS), width=128, height=64)
step("screen driver")
from mp1.display import Screen
screen = Screen(display)
step("screen: all labels")

led = digitalio.DigitalInOut(board.LED)
led.switch_to_output()
from macropad.app import App, NoAddon, forget_modules
lights = sound = NoAddon()
if cfg["led_count"] > 0:
    from mp1.lights import Lights
    lights = Lights(cfg, wiring.LED_STRIP_PIN)
    if lights.pixels is None:
        lights = NoAddon(lights.error)
step("LED strip ({} LEDs)".format(cfg["led_count"]))
if cfg["buzzer"] != "none":
    from mp1.sound import Sound
    sound = Sound(cfg, wiring.BUZZER_PIN)
    if not sound.present:
        sound = NoAddon(sound.error)
step("buzzer ({})".format(cfg["buzzer"]))

from mp1.actions import Actions
kbd = Keyboard(usb_hid.devices)
actions = Actions(kbd, KeyboardLayoutUS(kbd), ConsumerControl(usb_hid.devices), Mouse(usb_hid.devices))
step("USB keyboard / mouse / media")

keys = keypad.KeyMatrix(row_pins=wiring.ROWS, column_pins=wiring.COLS, columns_to_anodes=True)
encoder = rotaryio.IncrementalEncoder(wiring.ENC_A, wiring.ENC_B, divisor=cfg["encoder_divisor"])
button = digitalio.DigitalInOut(wiring.ENC_SW)
button.switch_to_input(pull=digitalio.Pull.UP)
step("keys, encoder, button")

errors = wiring.errors + keymap.ERRORS + settings.ERRORS
del wiring, pins, keymap, settings
forget_modules("pins", "keymap", "settings", "jsfile")
step("pins, keymap, settings, jsfile let go")
gone = [name for name, part in (("lights", lights), ("sound", sound)) if isinstance(part, NoAddon)]
Lights = Sound = None
forget_modules(*gone)
step("not fitted, let go: " + (", ".join(gone) or "none"))
km.layer(km.DEFAULT_LAYER)
step("home layer unpacked")
app = App(keymap=km,cfg=cfg, errors=errors, screen=screen, actions=actions, keys=keys,
          encoder=encoder, button=button, led=led, lights=lights, sound_out=sound)
step("main loop object (ready to run)")
reserve = None
step("room kept for later: free again")
from macropad import menus
m = menus.tools_menu(cfg)
step("TOOLS menu open (menus.py)")
m = menus = None
forget_modules("menus")
step("TOOLS menu closed")
# The first time, some of what the menu took stays: CircuitPython's table of names grows by a
# chunk, kept for good (later modules use the room). Opening it again shows its real cost.
from macropad import menus
m = menus.tools_menu(cfg)
step("TOOLS menu open again")
m = menus = None
forget_modules("menus")
step("TOOLS menu closed again")

print()
print("Lowest free: {} bytes. Comfortable while running: above ~15000.".format(_lowest[0]))
try:
    import micropython
    micropython.mem_info()          # "max free sz" = the largest single free block (x16 bytes)
except (ImportError, AttributeError):
    pass
print("Ctrl+D restarts the macropad normally.")
