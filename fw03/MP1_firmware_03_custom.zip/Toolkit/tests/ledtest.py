# Toolkit/tests/ledtest.py - standalone LED strip test (nothing else running).
# From the serial console: press Ctrl+C to stop code.py, any key for the >>> prompt, then:
#
#   from Toolkit.tests import ledtest     each LED lights red, green, blue and white in turn,
#                                 then all of them orange (and stay on)
#   ledtest.run(8)                the same for 8 LEDs (default: led_count from settings.json)
#
# Uses the LED strip pin from wiring.json (GP19 on a standard MP1). Press Ctrl+D afterwards
# to restart the macropad normally.

import time
from macropad import settings
from mp1 import pins

STEPS = (("red", (255, 0, 0)), ("green", (0, 255, 0)), ("blue", (0, 0, 255)), ("white", (255, 255, 255)))
ORANGE = (255, 80, 0)


def run(count=None, brightness=0.3, seconds=0.4):
    import neopixel
    wiring = pins.load()
    if wiring.LED_STRIP_PIN is None:
        print("No LED strip pin in wiring.json (led_strip is null): nothing to test.")
        return
    count = count or settings.load()["led_count"] or 4
    print("LED test: {} LED(s) on {}".format(count, wiring.LED_STRIP_PIN))
    strip = neopixel.NeoPixel(wiring.LED_STRIP_PIN, count, brightness=brightness, auto_write=False)
    try:
        for i in range(count):
            for name, rgb in STEPS:
                strip.fill((0, 0, 0))
                strip[i] = rgb
                strip.show()
                print("  LED {}: {}".format(i + 1, name))
                time.sleep(seconds)
        strip.fill(ORANGE)
        strip.show()
        print("All orange. If an LED stays dark, check the strip's 5V, GND and data wiring.")
    finally:
        strip.deinit()


run()
