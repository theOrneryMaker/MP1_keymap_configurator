Starter keymap for the MP1 firmware package.

keymap.json here is a generic keymap with six ready-made layers:
  MEDIA (home layer), EDIT, NAV, BROWSER, WINDOWS, PRESENT
No secret layers and no personal text. Built from the Keymap Configurator's templates.

To use it, copy keymap.json to the root of the MP1 drive (the macropad only
reads keymap.json from the root). Replace it with your own keymap.json whenever
you like (open it in mp1_configurator.html to edit or convert an old one).
