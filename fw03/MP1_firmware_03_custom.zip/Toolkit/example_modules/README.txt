Example modules (small add-on programs for the macropad).

Modules are off until switched on: TOOLS > SETTINGS > MODULES (or "modules": true in
settings.json, or Device settings > Modules in the configurator). A module is ordinary Python
and can do anything the firmware can, so only use modules you trust.

To use one: copy its folder into a folder called modules at the top of the MP1 drive (make
the folder if it isn't there):

    MP1 drive/modules/Responses/responses.py ...

(no restart needed). It's listed in the TOOLS menu, can be turned off on its own in
TOOLS > SETTINGS, and gestures / HOLD+KEY slots can open it ("mod:responses").

  Responses  saved replies: turn to pick one, click to type it
  Remind     a repeating reminder (stand up, drink water) that runs in the background

How to write your own: Toolkit/module_guide.html.
