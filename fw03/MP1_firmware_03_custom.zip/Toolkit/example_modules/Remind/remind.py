# Remind: a repeating reminder (stand up, drink water, look away from the screen).
# Open it, turn to pick how often, click to start (or stop). It then runs in the background,
# even with the module closed: when it's time, the screen flashes the reminder and beeps until
# the encoder is pressed (press twice to open Remind). Runs until stopped or the pad restarts.
# The reminder text is in remind.json in this folder ({"text": "STRETCH"}), or REMIND.

NAME = "REMIND"
ICON = "RMND"
API = 2

CHOICES = (15, 20, 30, 45, 60, 90, 120)     # minutes
pick = 2


def _text(mp):
    data = mp.read_json("remind.json", {})
    text = data.get("text") if isinstance(data, dict) else None
    return str(text or "REMIND")[:10].upper()


def _draw(mp):
    on = mp.state.get("every")
    title = "ON: EVERY {} MIN".format(on) if on else "OFF: CLICK TO START"
    if on and CHOICES[pick] == on:
        title = "ON: CLICK TO STOP"
    mp.show_big("{} MIN".format(CHOICES[pick]), title)


def on_open(mp):
    global pick
    every = mp.state.get("every") or mp.state.get("last", 30)
    pick = CHOICES.index(every) if every in CHOICES else 2
    _draw(mp)


def on_turn(mp, step):
    global pick
    pick = max(0, min(len(CHOICES) - 1, pick + step))
    _draw(mp)


def on_click(mp):
    minutes = CHOICES[pick]
    if mp.state.get("every") == minutes:
        mp.state["every"] = None
        mp.cancel_wake()
        mp.flash("STOPPED", 0.6)
    else:
        mp.state["every"] = mp.state["last"] = minutes
        mp.wake_in(minutes * 60)
        mp.flash("EVERY {}".format(minutes), 0.6)
    mp.close()


def on_due(mp):
    every = mp.state.get("every")
    if every:
        mp.notify(_text(mp))
        mp.wake_in(every * 60)          # and again
