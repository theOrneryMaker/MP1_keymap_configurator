RESPONSES - a module for the MP1 macropad
==========================================

Saved replies. Open it, turn the encoder to pick one, click to type it on the computer.
Keys 1-8 type replies 1-8 straight away. A longer press closes it without typing anything.


INSTALL
-------
1. Copy this whole Responses folder into a folder called modules on the MP1 drive (make it
   if it isn't there):

       MP1 drive/modules/Responses/responses.py
       MP1 drive/modules/Responses/responses_sample.json
       ...

2. Modules are off until you switch them on: TOOLS > SETTINGS > MODULES (or "modules": true
   in settings.json, or Device settings > Modules in the configurator).

RESPONSES is then listed in the TOOLS menu. To open it with a gesture or a HOLD+KEY slot,
pick RESPONSES in the Modules group of that slot's list in the configurator (User settings),
or set the slot to "mod:responses" in settings.json.


EDITING THE LIST
----------------
Open responses_editor.html (in this folder) in Chrome or Edge. Nothing to install.

  1. Open responses.json...  and pick responses.json in this folder on the MP1 drive
     (the first time, pick responses_sample.json, then Save as... responses.json).
  2. Edit, add, reorder or delete replies.
       Title: what the screen shows (up to 10 characters).
       Text:  what it types. A new line presses Enter.
  3. Save. The new list is used the next time RESPONSES opens.

The macropad types with a US keyboard layout, so replies can only use plain keyboard
characters. The editor flags anything else (curly quotes, long dashes, accents) in red.
If one slips through, the macropad leaves that character out.

"Close the module after typing a reply": untick it to keep it open after each reply.


responses.json
--------------
You can also edit the file by hand:

    {
      "close_after_send": true,
      "responses": [
        {"title": "THANKS", "text": "Thanks, I appreciate it!"},
        {"title": "SIGN OFF", "text": "\nBest regards,\n"}
      ]
    }

In JSON, \n is a new line (Enter) and \" is a quote mark.


FILES
-----
  responses.py            the module (runs on the macropad)
  responses.json          your replies (until you save one, responses_sample.json is used)
  responses_sample.json   the starting list
  responses_editor.html   the list editor (runs in your browser)
  README.txt              this file
