# Responses: saved replies. Turn to pick one, click to type it on the computer.
# Keys 1-8 type replies 1-8 straight away. A longer press closes it without typing.
# The replies are in responses.json in this folder (see README.txt); until there is one,
# the sample list (responses_sample.json) is used.

NAME = "RESPONSES"
ICON = "RESP"
API = 2

items = []          # [(title, text)] while open (the module is unloaded on close)
selected = 0
close_after = True


def _load(mp):
    global items, close_after
    data = mp.read_json("responses.json") or mp.read_json("responses_sample.json", {})
    if not isinstance(data, dict):
        data = {}
    close_after = data.get("close_after_send", True) is not False
    items = []
    for r in data.get("responses", []):
        if isinstance(r, dict) and isinstance(r.get("text"), str):
            # the US keyboard layout types plain characters only: drop anything else
            text = "".join(c for c in r["text"] if " " <= c <= "~" or c in "\n\t")
            if text:
                title = str(r.get("title") or text.strip().split("\n")[0])[:10].upper()
                items.append((title, text))


def _draw(mp):
    if not items:
        mp.show_big("EMPTY", "NO RESPONSES")
        return
    mp.show_big(items[selected][0], "RESPONSES {}/{}".format(selected + 1, len(items)))


def _send(mp, index):
    mp.type(items[index][1])
    mp.state["last"] = index            # opens on it next time (until the macropad restarts)
    if close_after:
        mp.close()
    else:
        mp.flash("SENT", 0.4)
        _draw(mp)


def on_open(mp):
    global selected
    _load(mp)
    last = mp.state.get("last", 0)
    selected = last if isinstance(last, int) and 0 <= last < len(items) else 0
    _draw(mp)


def on_turn(mp, step):
    global selected
    if items:
        selected = (selected + step) % len(items)     # same direction as the layer picker
        _draw(mp)


def on_click(mp):
    if items:
        _send(mp, selected)


def on_key(mp, number):
    if number < len(items):
        _send(mp, number)
