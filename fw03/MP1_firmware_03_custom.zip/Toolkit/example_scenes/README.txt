Example lighting scenes (data files: they only change colors).

To use one: copy it into a folder called scenes at the top of the MP1 drive (make the folder
if it isn't there) and restart the macropad. It's then listed after the built-in scenes in
TOOLS > LIGHTS > SCENE, and in the configurator (LIGHTS scene and each layer's lights).

  SUNRISE  indigo night, orange dawn, warm day, and back (slow)
  OCEAN    blues drifting along the strip
  BEACON   alternating COLOR 1 / COLOR 2, white flash on each key press
  CALM     slow fade between COLOR 1 and COLOR 2, warm flash on key press

The file name is the scene's name (ocean.mp1scene.json is OCEAN): rename a copy to make
your own version.

COLOR 1 / COLOR 2 are the colors chosen in LIGHTS (or a layer's own lights), so one scene
works in any color scheme. See help.html, "Drop-in Scenes", for how to write your own.
